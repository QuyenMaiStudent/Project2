<?php

namespace Database\Factories;

use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends \Illuminate\Database\Eloquent\Factories\Factory<\App\Models\ProductImage>
 */
class ProductImageFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'product_id' => Product::inRandomOrder()->first()?->id ?? Product::factory(),
            'url' => $this->faker->imageUrl(600, 600, 'products', true, 'Product'),
            'alt_text' => $this->faker->sentence(3),
            'is_primary' => $this->faker->boolean(20), // 20% chance to be primary
        ];
    }
}
